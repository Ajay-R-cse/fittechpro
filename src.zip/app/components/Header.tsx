import React from 'react';
import { Activity, Apple, MessageSquare, LayoutDashboard, UserCircle } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'workouts', label: 'Workouts', icon: Activity },
    { id: 'nutrition', label: 'Nutrition', icon: Apple },
    { id: 'ai', label: 'AI Coach', icon: MessageSquare },
    { id: 'profile', label: 'Profile', icon: UserCircle },
  ];

  return (
    <header className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-4 py-2 z-50 md:top-0 md:bottom-auto md:border-t-0 md:border-b">
      <div className="max-w-7xl mx-auto flex justify-around md:justify-between items-center">
        <div className="hidden md:flex items-center gap-2 font-bold text-xl text-indigo-600">
          <Activity className="w-8 h-8" />
          <span>FitTech Pro</span>
        </div>
        
        <nav className="flex gap-4 md:gap-8 flex-1 justify-around md:justify-end">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col md:flex-row items-center gap-1 md:gap-2 px-3 py-1 rounded-lg transition-colors ${
                  isActive 
                    ? 'text-indigo-600 md:bg-indigo-50' 
                    : 'text-slate-500 hover:text-indigo-600'
                }`}
              >
                <Icon className="w-6 h-6 md:w-5 md:h-5" />
                <span className="text-xs md:text-sm font-medium">{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
