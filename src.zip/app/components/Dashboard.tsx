import React from 'react';
import { motion } from 'motion/react';
import { Flame, Target, Trophy, TrendingUp } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';
import { ImageWithFallback } from '@/app/components/figma/ImageWithFallback';

interface DashboardProps {
  userName: string;
  stats: {
    caloriesEaten: number;
    caloriesGoal: number;
    protein: number;
    proteinGoal: number;
    carbs: number;
    carbsGoal: number;
    fats: number;
    fatsGoal: number;
    workoutsThisWeek: number;
  };
}

export const Dashboard: React.FC<DashboardProps> = ({ userName, stats }) => {
  const macroData = [
    { name: 'Protein', value: stats.protein, color: '#6366f1' },
    { name: 'Carbs', value: stats.carbs, color: '#10b981' },
    { name: 'Fats', value: stats.fats, color: '#f59e0b' },
  ];

  const weeklyActivity = [
    { day: 'Mon', sessions: 1 },
    { day: 'Tue', sessions: 0 },
    { day: 'Wed', sessions: 1 },
    { day: 'Thu', sessions: 1 },
    { day: 'Fri', sessions: 0 },
    { day: 'Sat', sessions: 0 },
    { day: 'Sun', sessions: 0 },
  ];

  const caloriePercentage = Math.min((stats.caloriesEaten / stats.caloriesGoal) * 100, 100);

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <section className="relative h-48 rounded-2xl overflow-hidden flex items-center px-8 text-white">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1540205453279-389ebbc43b5b"
          alt="Gym"
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-transparent" />
        <div className="relative z-10">
          <h1 className="text-3xl font-bold mb-2">Welcome back, {userName.split(' ')[0]}!</h1>
          <p className="text-slate-200">You've completed {stats.workoutsThisWeek} workouts this week. Keep going!</p>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Calorie Tracker */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
        >
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-slate-800 flex items-center gap-2">
              <Flame className="w-5 h-5 text-orange-500" />
              Daily Calories
            </h3>
            <span className="text-sm text-slate-500">{stats.caloriesEaten} / {stats.caloriesGoal} kcal</span>
          </div>
          <div className="h-4 w-full bg-slate-100 rounded-full overflow-hidden mb-4">
            <div 
              className="h-full bg-orange-500 transition-all duration-500" 
              style={{ width: `${caloriePercentage}%` }} 
            />
          </div>
          <div className="grid grid-cols-3 gap-2 text-center">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-bold">Protein</p>
              <p className="text-sm font-bold text-slate-800">{stats.protein} / {stats.proteinGoal}g</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-bold">Carbs</p>
              <p className="text-sm font-bold text-slate-800">{stats.carbs} / {stats.carbsGoal}g</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-bold">Fats</p>
              <p className="text-sm font-bold text-slate-800">{stats.fats} / {stats.fatsGoal}g</p>
            </div>
          </div>
        </motion.div>

        {/* Macro Distribution */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center"
        >
          <h3 className="font-semibold text-slate-800 mb-4 self-start flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-500" />
            Macro Split
          </h3>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={macroData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {macroData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        {/* Weekly Activity */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100"
        >
          <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
            Weekly Consistency
          </h3>
          <div className="h-40 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={weeklyActivity}>
                <XAxis dataKey="day" axisLine={false} tickLine={false} fontSize={12} />
                <YAxis hide />
                <Tooltip cursor={{ fill: '#f8fafc' }} />
                <Bar dataKey="sessions" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>

      <section className="bg-indigo-600 rounded-2xl p-6 text-white flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <h2 className="text-xl font-bold mb-2 flex items-center gap-2">
            <Trophy className="w-6 h-6 text-yellow-400" />
            Personal Best Reached!
          </h2>
          <p className="text-indigo-100">You squatted 120kg for the first time yesterday. Keep pushing your limits!</p>
        </div>
        <button className="bg-white text-indigo-600 px-6 py-2 rounded-xl font-semibold hover:bg-indigo-50 transition-colors">
          View Achievements
        </button>
      </section>
    </div>
  );
};
