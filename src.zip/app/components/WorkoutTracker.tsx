import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, ChevronDown, ChevronUp, Save, Clock, Dumbbell } from 'lucide-react';

interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight: number;
}

interface Workout {
  id: string;
  date: string;
  type: string;
  exercises: Exercise[];
}

interface WorkoutTrackerProps {
  workouts: Workout[];
  onAddWorkout: (workout: Workout) => void;
}

export const WorkoutTracker: React.FC<WorkoutTrackerProps> = ({ workouts, onAddWorkout }) => {
  const [isAdding, setIsAdding] = useState(false);
  const [newWorkoutType, setNewWorkoutType] = useState('Push');
  const [newExercises, setNewExercises] = useState<Exercise[]>([
    { id: '1', name: '', sets: 0, reps: 0, weight: 0 }
  ]);

  const addExerciseField = () => {
    setNewExercises([...newExercises, { id: Math.random().toString(), name: '', sets: 0, reps: 0, weight: 0 }]);
  };

  const removeExerciseField = (id: string) => {
    setNewExercises(newExercises.filter(e => e.id !== id));
  };

  const updateExercise = (id: string, field: keyof Exercise, value: string | number) => {
    setNewExercises(newExercises.map(e => e.id === id ? { ...e, [field]: value } : e));
  };

  const handleSave = () => {
    if (newExercises.some(e => !e.name)) return;
    
    const workout: Workout = {
      id: Math.random().toString(),
      date: new Date().toLocaleDateString(),
      type: newWorkoutType,
      exercises: newExercises
    };
    onAddWorkout(workout);
    setIsAdding(false);
    setNewExercises([{ id: '1', name: '', sets: 0, reps: 0, weight: 0 }]);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-24">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-slate-800">Workout Log</h2>
        <button 
          onClick={() => setIsAdding(!isAdding)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-indigo-700 transition-colors"
        >
          {isAdding ? <ChevronUp className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          {isAdding ? 'Close' : 'Log Workout'}
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-white p-6 rounded-2xl shadow-sm border-2 border-indigo-100 overflow-hidden"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Workout Type</label>
                <select 
                  value={newWorkoutType}
                  onChange={(e) => setNewWorkoutType(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option>Push</option>
                  <option>Pull</option>
                  <option>Legs</option>
                  <option>Cardio</option>
                  <option>Full Body</option>
                </select>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <h4 className="font-medium text-slate-700">Exercises</h4>
              {newExercises.map((exercise, index) => (
                <div key={exercise.id} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-12 md:col-span-5">
                    <input 
                      placeholder="Exercise Name (e.g. Bench Press)"
                      className="w-full p-2 rounded-lg border border-slate-200"
                      value={exercise.name}
                      onChange={(e) => updateExercise(exercise.id, 'name', e.target.value)}
                    />
                  </div>
                  <div className="col-span-3 md:col-span-2">
                    <label className="block text-[10px] text-slate-500 uppercase">Sets</label>
                    <input 
                      type="number"
                      placeholder="0"
                      className="w-full p-2 rounded-lg border border-slate-200"
                      value={exercise.sets || ''}
                      onChange={(e) => updateExercise(exercise.id, 'sets', parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-3 md:col-span-2">
                    <label className="block text-[10px] text-slate-500 uppercase">Reps</label>
                    <input 
                      type="number"
                      placeholder="0"
                      className="w-full p-2 rounded-lg border border-slate-200"
                      value={exercise.reps || ''}
                      onChange={(e) => updateExercise(exercise.id, 'reps', parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <label className="block text-[10px] text-slate-500 uppercase">Weight (kg)</label>
                    <input 
                      type="number"
                      placeholder="0"
                      className="w-full p-2 rounded-lg border border-slate-200"
                      value={exercise.weight || ''}
                      onChange={(e) => updateExercise(exercise.id, 'weight', parseInt(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-2 md:col-span-1 flex justify-center pb-2">
                    <button 
                      onClick={() => removeExerciseField(exercise.id)}
                      className="text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-between">
              <button 
                onClick={addExerciseField}
                className="text-indigo-600 font-medium flex items-center gap-1 hover:text-indigo-700"
              >
                <Plus className="w-4 h-4" /> Add Exercise
              </button>
              <button 
                onClick={handleSave}
                className="bg-indigo-600 text-white px-6 py-2 rounded-xl flex items-center gap-2 hover:bg-indigo-700"
              >
                <Save className="w-4 h-4" /> Save Workout
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {workouts.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-2xl border border-dashed border-slate-300">
            <Dumbbell className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No workouts recorded yet. Start training!</p>
          </div>
        ) : (
          workouts.map((workout) => (
            <div key={workout.id} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-bold text-slate-800 text-lg">{workout.type} Session</h3>
                  <p className="text-sm text-slate-500 flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {workout.date}
                  </p>
                </div>
                <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                  {workout.exercises.length} Exercises
                </span>
              </div>
              
              <div className="space-y-3">
                {workout.exercises.map((ex, i) => (
                  <div key={i} className="flex justify-between items-center py-2 border-t border-slate-50 last:border-b-0">
                    <span className="font-medium text-slate-700">{ex.name}</span>
                    <div className="flex gap-4 text-sm">
                      <span className="text-slate-500"><span className="text-slate-800 font-semibold">{ex.sets}</span> sets</span>
                      <span className="text-slate-500"><span className="text-slate-800 font-semibold">{ex.reps}</span> reps</span>
                      <span className="text-slate-500"><span className="text-slate-800 font-semibold">{ex.weight}</span> kg</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
