import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Bot, User, Sparkles, Lightbulb, Dumbbell, Apple } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'ai' | 'user';
}

export const AIAssistant: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Hello! I'm your AI Fitness Coach. How can I help you reach your goals today?", sender: 'ai' }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg: Message = { id: Date.now().toString(), text: input, sender: 'user' };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const response = getAIResponse(input);
      const aiMsg: Message = { id: (Date.now() + 1).toString(), text: response, sender: 'ai' };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, 1500);
  };

  const getAIResponse = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes('eat') || q.includes('food') || q.includes('diet')) {
      return "For recovery after training, focus on a mix of high-quality protein (like chicken, fish, or tofu) and complex carbohydrates (like sweet potatoes or quinoa) to replenish glycogen stores. Don't forget to hydrate!";
    }
    if (q.includes('workout') || q.includes('exercise') || q.includes('muscle')) {
      return "Based on your goal of muscle gain, I recommend a 'Push/Pull/Legs' split. Today is a great day for heavy compound movements like squats or deadlifts. Remember to maintain progressive overload!";
    }
    if (q.includes('motivation') || q.includes('tired')) {
      return "Remember why you started. One bad workout is better than no workout at all. You're building a better version of yourself every single day. Let's get moving!";
    }
    return "That's a great question! For your specific fitness level, I'd suggest focusing on consistency over intensity right now. Do you have any specific goals for this week?";
  };

  const suggestions = [
    { text: "What should I eat after leg day?", icon: Apple },
    { text: "Suggest a fat loss workout", icon: Dumbbell },
    { text: "Give me some motivation", icon: Sparkles },
    { text: "How much protein do I need?", icon: Lightbulb },
  ];

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] md:h-[calc(100vh-100px)] max-w-4xl mx-auto bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden">
      <div className="p-4 border-b border-slate-100 bg-indigo-50/50 flex items-center gap-3">
        <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center">
          <Bot className="text-white w-6 h-6" />
        </div>
        <div>
          <h3 className="font-bold text-slate-800">FitTech Pro AI Coach</h3>
          <p className="text-xs text-indigo-600 font-medium">Always Online</p>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/30">
        {messages.map((msg) => (
          <motion.div
            key={msg.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div className={`max-w-[80%] p-4 rounded-2xl ${
              msg.sender === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-white text-slate-700 shadow-sm border border-slate-100 rounded-tl-none'
            }`}>
              <p className="text-sm md:text-base leading-relaxed">{msg.text}</p>
            </div>
          </motion.div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-slate-100">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce" />
                <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:0.2s]" />
                <span className="w-2 h-2 bg-slate-300 rounded-full animate-bounce [animation-delay:0.4s]" />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-slate-100 bg-white">
        <div className="flex gap-2 overflow-x-auto pb-4 mb-4 no-scrollbar">
          {suggestions.map((s, i) => {
            const Icon = s.icon;
            return (
              <button
                key={i}
                onClick={() => { setInput(s.text); }}
                className="whitespace-nowrap flex items-center gap-2 px-4 py-2 bg-slate-50 hover:bg-indigo-50 border border-slate-100 rounded-full text-xs font-medium text-slate-600 transition-colors"
              >
                <Icon className="w-3 h-3 text-indigo-500" />
                {s.text}
              </button>
            );
          })}
        </div>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Ask anything about fitness..."
            className="flex-1 p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <button
            onClick={handleSend}
            className="bg-indigo-600 text-white p-3 rounded-xl hover:bg-indigo-700 transition-colors"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
