import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Apple, Search, Coffee, Utensils, Moon, Info, Camera, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
}

interface NutritionTrackerProps {
  meals: Meal[];
  onAddMeal: (meal: Meal) => void;
  dailyGoal: number;
  proteinGoal: number;
  carbsGoal: number;
  fatsGoal: number;
}

export const NutritionTracker: React.FC<NutritionTrackerProps> = ({ 
  meals, 
  onAddMeal, 
  dailyGoal,
  proteinGoal,
  carbsGoal,
  fatsGoal
}) => {
  const [isAdding, setIsAdding] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [newMeal, setNewMeal] = useState({
    name: '',
    calories: 0,
    protein: 0,
    carbs: 0,
    fats: 0,
    type: 'Lunch' as Meal['type']
  });

  const totals = meals.reduce((acc, meal) => ({
    calories: acc.calories + (meal.calories || 0),
    protein: acc.protein + (meal.protein || 0),
    carbs: acc.carbs + (meal.carbs || 0),
    fats: acc.fats + (meal.fats || 0)
  }), { calories: 0, protein: 0, carbs: 0, fats: 0 });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setIsAnalyzing(true);
      setIsAdding(true);
      
      // Simulate AI Food Analysis
      setTimeout(() => {
        const mockAnalysis = {
          name: 'Grilled Salmon with Quinoa',
          calories: 520,
          protein: 42,
          carbs: 35,
          fats: 22,
          type: 'Lunch' as const
        };
        
        setNewMeal(mockAnalysis);
        setIsAnalyzing(false);
        toast.success('AI Analysis Complete!', {
          description: `Identified: ${mockAnalysis.name}`,
          icon: <Sparkles className="w-4 h-4 text-amber-500" />
        });
      }, 2500);
    }
  };

  const handleAdd = () => {
    if (!newMeal.name) return;
    onAddMeal({ ...newMeal, id: Math.random().toString() });
    setIsAdding(false);
    setNewMeal({ name: '', calories: 0, protein: 0, carbs: 0, fats: 0, type: 'Lunch' });
  };

  const mealTypes = [
    { name: 'Breakfast', icon: Coffee, color: 'text-orange-500' },
    { name: 'Lunch', icon: Utensils, color: 'text-emerald-500' },
    { name: 'Dinner', icon: Moon, color: 'text-indigo-500' },
    { name: 'Snack', icon: Apple, color: 'text-rose-500' },
  ];

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-24">
      {/* Summary Header */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col md:flex-row justify-between items-center gap-6">
        <div className="text-center md:text-left">
          <h2 className="text-sm text-slate-500 font-medium uppercase tracking-wider mb-1">Calories Remaining</h2>
          <p className="text-4xl font-bold text-slate-800">{dailyGoal - totals.calories}</p>
        </div>
        <div className="flex gap-8 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
          <div className="text-center min-w-[80px]">
            <p className="text-2xl font-bold text-slate-800">{totals.protein}<span className="text-sm text-slate-400 font-normal">/{proteinGoal}g</span></p>
            <p className="text-xs text-slate-500 uppercase">Protein</p>
            <div className="h-1 w-full bg-slate-100 rounded-full mt-1">
              <div className="h-full bg-indigo-500 rounded-full" style={{ width: `${Math.min((totals.protein / proteinGoal) * 100, 100)}%` }} />
            </div>
          </div>
          <div className="text-center border-x border-slate-100 px-8 min-w-[80px]">
            <p className="text-2xl font-bold text-slate-800">{totals.carbs}<span className="text-sm text-slate-400 font-normal">/{carbsGoal}g</span></p>
            <p className="text-xs text-slate-500 uppercase">Carbs</p>
            <div className="h-1 w-full bg-slate-100 rounded-full mt-1">
              <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${Math.min((totals.carbs / carbsGoal) * 100, 100)}%` }} />
            </div>
          </div>
          <div className="text-center min-w-[80px]">
            <p className="text-2xl font-bold text-slate-800">{totals.fats}<span className="text-sm text-slate-400 font-normal">/{fatsGoal}g</span></p>
            <p className="text-xs text-slate-500 uppercase">Fats</p>
            <div className="h-1 w-full bg-slate-100 rounded-full mt-1">
              <div className="h-full bg-amber-500 rounded-full" style={{ width: `${Math.min((totals.fats / fatsGoal) * 100, 100)}%` }} />
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-between items-center">
        <h3 className="text-xl font-bold text-slate-800">Today's Meals</h3>
        <div className="flex gap-2">
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            ref={fileInputRef}
            onChange={handleImageUpload}
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-indigo-100 transition-colors border border-indigo-100"
          >
            <Camera className="w-5 h-5" /> 
            <span className="hidden sm:inline">AI Photo Log</span>
          </button>
          <button 
            onClick={() => setIsAdding(!isAdding)}
            className="bg-emerald-600 text-white px-4 py-2 rounded-xl flex items-center gap-2 hover:bg-emerald-700 transition-colors"
          >
            <Plus className="w-5 h-5" /> Log Food
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white p-6 rounded-2xl shadow-sm border-2 border-emerald-100 relative overflow-hidden"
          >
            {isAnalyzing && (
              <div className="absolute inset-0 bg-white/80 backdrop-blur-sm z-10 flex flex-col items-center justify-center">
                <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mb-2" />
                <p className="font-bold text-slate-800">Analyzing Food...</p>
                <p className="text-sm text-slate-500">Extracting nutritional data</p>
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Food Name</label>
                <input 
                  type="text"
                  placeholder="e.g. Grilled Chicken Salad"
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.name}
                  onChange={(e) => setNewMeal({ ...newMeal, name: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Meal Type</label>
                <select 
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.type}
                  onChange={(e) => setNewMeal({ ...newMeal, type: e.target.value as Meal['type'] })}
                >
                  <option>Breakfast</option>
                  <option>Lunch</option>
                  <option>Dinner</option>
                  <option>Snack</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div>
                <label className="block text-xs text-slate-500 uppercase mb-1">Calories</label>
                <input 
                  type="number"
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.calories || ''}
                  onChange={(e) => setNewMeal({ ...newMeal, calories: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 uppercase mb-1">Protein (g)</label>
                <input 
                  type="number"
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.protein || ''}
                  onChange={(e) => setNewMeal({ ...newMeal, protein: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 uppercase mb-1">Carbs (g)</label>
                <input 
                  type="number"
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.carbs || ''}
                  onChange={(e) => setNewMeal({ ...newMeal, carbs: parseInt(e.target.value) || 0 })}
                />
              </div>
              <div>
                <label className="block text-xs text-slate-500 uppercase mb-1">Fats (g)</label>
                <input 
                  type="number"
                  className="w-full p-2 rounded-lg border border-slate-200"
                  value={newMeal.fats || ''}
                  onChange={(e) => setNewMeal({ ...newMeal, fats: parseInt(e.target.value) || 0 })}
                />
              </div>
            </div>
            <button 
              onClick={handleAdd}
              className="w-full bg-emerald-600 text-white py-3 rounded-xl font-bold hover:bg-emerald-700 transition-colors"
            >
              Add to Diary
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-6">
        {mealTypes.map((typeInfo) => {
          const typeMeals = meals.filter(m => m.type === typeInfo.name);
          const Icon = typeInfo.icon;
          return (
            <div key={typeInfo.name} className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100">
              <div className="px-6 py-4 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${typeInfo.color}`} />
                  <h4 className="font-bold text-slate-800">{typeInfo.name}</h4>
                </div>
                <span className="text-sm font-medium text-slate-500">
                  {typeMeals.reduce((sum, m) => sum + m.calories, 0)} kcal
                </span>
              </div>
              <div className="divide-y divide-slate-50">
                {typeMeals.length > 0 ? (
                  typeMeals.map((meal) => (
                    <div key={meal.id} className="px-6 py-3 flex justify-between items-center group">
                      <div>
                        <p className="font-medium text-slate-700">{meal.name}</p>
                        <p className="text-xs text-slate-400">P: {meal.protein}g | C: {meal.carbs}g | F: {meal.fats}g</p>
                      </div>
                      <span className="text-slate-600 font-medium">{meal.calories} kcal</span>
                    </div>
                  ))
                ) : (
                  <div className="px-6 py-4 text-sm text-slate-400 flex items-center gap-2">
                    <Info className="w-4 h-4" /> No items logged
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
