import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Scale, Ruler, FileText, Target, Save, CheckCircle, Flame, Droplets, Zap, Dumbbell } from 'lucide-react';
import { toast } from 'sonner';

interface ProfileData {
  name: string;
  height: number;
  weight: number;
  bio: string;
  goal: string;
  caloriesGoal: number;
  proteinGoal: number;
  carbsGoal: number;
  fatsGoal: number;
}

interface ProfileProps {
  profile: ProfileData;
  onUpdateProfile: (data: ProfileData) => void;
}

export const Profile: React.FC<ProfileProps> = ({ profile, onUpdateProfile }) => {
  const [formData, setFormData] = useState<ProfileData>(profile);
  const [isEditing, setIsEditing] = useState(false);

  const calculateBMI = (w: number, h: number) => {
    if (!w || !h) return 0;
    const heightInMeters = h / 100;
    return (w / (heightInMeters * heightInMeters)).toFixed(1);
  };

  const getBMICategory = (bmi: number) => {
    if (bmi < 18.5) return { label: 'Underweight', color: 'text-blue-500' };
    if (bmi < 25) return { label: 'Normal', color: 'text-emerald-500' };
    if (bmi < 30) return { label: 'Overweight', color: 'text-orange-500' };
    return { label: 'Obese', color: 'text-red-500' };
  };

  const bmiValue = parseFloat(calculateBMI(formData.weight, formData.height));
  const bmiInfo = getBMICategory(bmiValue);

  const handleSave = () => {
    onUpdateProfile(formData);
    setIsEditing(false);
    toast.success('Profile updated successfully!');
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-24">
      <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
        <div className="flex flex-col items-center mb-8">
          <div className="w-24 h-24 bg-indigo-100 rounded-full flex items-center justify-center mb-4 border-4 border-white shadow-sm">
            <User className="w-12 h-12 text-indigo-600" />
          </div>
          <h2 className="text-2xl font-bold text-slate-800">{profile.name || 'Set your name'}</h2>
          <p className="text-slate-500">{profile.goal || 'No goal set'}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-8">
          <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">BMI Score</p>
            <p className={`text-3xl font-bold ${bmiInfo.color}`}>{bmiValue}</p>
            <p className={`text-xs font-medium ${bmiInfo.color}`}>{bmiInfo.label}</p>
          </div>
          <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
            <p className="text-xs text-slate-500 uppercase font-bold tracking-wider mb-1">Current Weight</p>
            <p className="text-3xl font-bold text-slate-800">{formData.weight}<span className="text-lg ml-1 font-normal text-slate-400">kg</span></p>
            <p className="text-xs text-slate-400 font-medium">Last updated today</p>
          </div>
        </div>

        <div className="space-y-6">
          <div className="flex justify-between items-center border-b border-slate-50 pb-2">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-500" />
              Personal Details
            </h3>
            {!isEditing && (
              <button 
                onClick={() => setIsEditing(true)}
                className="text-indigo-600 text-sm font-semibold hover:underline"
              >
                Edit Profile
              </button>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
              <input 
                type="text"
                disabled={!isEditing}
                className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Ruler className="w-4 h-4" /> Height (cm)
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.height || ''}
                  onChange={(e) => setFormData({...formData, height: parseInt(e.target.value) || 0})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Scale className="w-4 h-4" /> Weight (kg)
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.weight || ''}
                  onChange={(e) => setFormData({...formData, weight: parseInt(e.target.value) || 0})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                <Target className="w-4 h-4" /> Fitness Goal
              </label>
              <select
                disabled={!isEditing}
                className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                value={formData.goal}
                onChange={(e) => setFormData({...formData, goal: e.target.value})}
              >
                <option value="Fat Loss">Fat Loss</option>
                <option value="Muscle Gain">Muscle Gain</option>
                <option value="Maintenance">Maintenance</option>
                <option value="General Health">General Health</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Personal Bio</label>
              <textarea 
                rows={3}
                disabled={!isEditing}
                className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none"
                placeholder="Tell us about yourself..."
                value={formData.bio}
                onChange={(e) => setFormData({...formData, bio: e.target.value})}
              />
            </div>
          </div>

          <div className="pt-6 border-t border-slate-50 space-y-4">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-500" />
              Daily Nutrition Goals
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Flame className="w-4 h-4" /> Daily Calories
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.caloriesGoal || ''}
                  onChange={(e) => setFormData({...formData, caloriesGoal: parseInt(e.target.value) || 0})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Dumbbell className="w-4 h-4" /> Protein Goal (g)
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.proteinGoal || ''}
                  onChange={(e) => setFormData({...formData, proteinGoal: parseInt(e.target.value) || 0})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Zap className="w-4 h-4" /> Carbs Goal (g)
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.carbsGoal || ''}
                  onChange={(e) => setFormData({...formData, carbsGoal: parseInt(e.target.value) || 0})}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1 flex items-center gap-2">
                  <Droplets className="w-4 h-4" /> Fats Goal (g)
                </label>
                <input 
                  type="number"
                  disabled={!isEditing}
                  className="w-full p-3 rounded-xl border border-slate-200 disabled:bg-slate-50 disabled:text-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  value={formData.fatsGoal || ''}
                  onChange={(e) => setFormData({...formData, fatsGoal: parseInt(e.target.value) || 0})}
                />
              </div>
            </div>
          </div>

          {isEditing && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex gap-3"
            >
              <button 
                onClick={handleSave}
                className="flex-1 bg-indigo-600 text-white py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-colors"
              >
                <Save className="w-5 h-5" /> Save Changes
              </button>
              <button 
                onClick={() => { setFormData(profile); setIsEditing(false); }}
                className="px-6 py-3 rounded-xl border border-slate-200 font-bold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
            </motion.div>
          )}
        </div>
      </div>

      <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100 flex items-start gap-4">
        <div className="bg-emerald-500 p-2 rounded-xl text-white">
          <CheckCircle className="w-6 h-6" />
        </div>
        <div>
          <h4 className="font-bold text-emerald-900">Weekly Progress</h4>
          <p className="text-emerald-700 text-sm">You've hit your protein goal 5 days in a row! Your consistency is leading to real results.</p>
        </div>
      </div>
    </div>
  );
};
