import React, { useState, useEffect } from 'react';
import { Header } from '@/app/components/Header';
import { Dashboard } from '@/app/components/Dashboard';
import { WorkoutTracker } from '@/app/components/WorkoutTracker';
import { NutritionTracker } from '@/app/components/NutritionTracker';
import { AIAssistant } from '@/app/components/AIAssistant';
import { Profile } from '@/app/components/Profile';
import { Toaster, toast } from 'sonner';

// Types
interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight: number;
}

interface Workout {
  id: string;
  date: string;
  type: string;
  exercises: Exercise[];
}

interface Meal {
  id: string;
  name: string;
  calories: number;
  protein: number;
  carbs: number;
  fats: number;
  type: 'Breakfast' | 'Lunch' | 'Dinner' | 'Snack';
}

interface ProfileData {
  name: string;
  height: number;
  weight: number;
  bio: string;
  goal: string;
  caloriesGoal: number;
  proteinGoal: number;
  carbsGoal: number;
  fatsGoal: number;
}

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  
  // Persistence with LocalStorage
  const [profile, setProfile] = useState<ProfileData>(() => {
    const saved = localStorage.getItem('fittech_pro_profile');
    return saved ? JSON.parse(saved) : {
      name: 'Alex Johnson',
      height: 180,
      weight: 75,
      bio: 'Fitness enthusiast working towards a marathon.',
      goal: 'Muscle Gain',
      caloriesGoal: 2500,
      proteinGoal: 180,
      carbsGoal: 250,
      fatsGoal: 70
    };
  });

  const [workouts, setWorkouts] = useState<Workout[]>(() => {
    const saved = localStorage.getItem('fittech_pro_workouts');
    return saved ? JSON.parse(saved) : [
      {
        id: '1',
        date: '1/28/2026',
        type: 'Push',
        exercises: [
          { id: '1-1', name: 'Bench Press', sets: 3, reps: 10, weight: 80 },
          { id: '1-2', name: 'Overhead Press', sets: 3, reps: 8, weight: 40 }
        ]
      }
    ];
  });

  const [meals, setMeals] = useState<Meal[]>(() => {
    const saved = localStorage.getItem('fittech_pro_meals');
    return saved ? JSON.parse(saved) : [
      { id: 'm1', name: 'Oatmeal with Berries', calories: 350, protein: 12, carbs: 55, fats: 8, type: 'Breakfast' },
      { id: 'm2', name: 'Chicken Breast & Rice', calories: 600, protein: 45, carbs: 60, fats: 10, type: 'Lunch' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('fittech_pro_workouts', JSON.stringify(workouts));
  }, [workouts]);

  useEffect(() => {
    localStorage.setItem('fittech_pro_meals', JSON.stringify(meals));
  }, [meals]);

  useEffect(() => {
    localStorage.setItem('fittech_pro_profile', JSON.stringify(profile));
  }, [profile]);

  const handleAddWorkout = (workout: Workout) => {
    setWorkouts([workout, ...workouts]);
    toast.success('Workout logged successfully!');
  };

  const handleAddMeal = (meal: Meal) => {
    setMeals([...meals, meal]);
    toast.success('Meal added to diary!');
  };

  // Derived Stats
  const totals = meals.reduce((acc, meal) => ({
    calories: acc.calories + (meal.calories || 0),
    protein: acc.protein + (meal.protein || 0),
    carbs: acc.carbs + (meal.carbs || 0),
    fats: acc.fats + (meal.fats || 0)
  }), { calories: 0, protein: 0, carbs: 0, fats: 0 });

  const stats = {
    caloriesEaten: totals.calories,
    caloriesGoal: profile.caloriesGoal,
    protein: totals.protein,
    proteinGoal: profile.proteinGoal,
    carbs: totals.carbs,
    carbsGoal: profile.carbsGoal,
    fats: totals.fats,
    fatsGoal: profile.fatsGoal,
    workoutsThisWeek: workouts.length,
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard userName={profile.name} stats={stats} />;
      case 'workouts':
        return <WorkoutTracker workouts={workouts} onAddWorkout={handleAddWorkout} />;
      case 'nutrition':
        return (
          <NutritionTracker 
            meals={meals} 
            onAddMeal={handleAddMeal} 
            dailyGoal={stats.caloriesGoal}
            proteinGoal={stats.proteinGoal}
            carbsGoal={stats.carbsGoal}
            fatsGoal={stats.fatsGoal}
          />
        );
      case 'ai':
        return <AIAssistant />;
      case 'profile':
        return <Profile profile={profile} onUpdateProfile={setProfile} />;
      default:
        return <Dashboard stats={stats} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      <Header activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="max-w-7xl mx-auto px-4 pt-4 md:pt-24 pb-24 md:pb-8">
        {renderContent()}
      </main>

      <Toaster position="top-right" />
    </div>
  );
};

export default App;
